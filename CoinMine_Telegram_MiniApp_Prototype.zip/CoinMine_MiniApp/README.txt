# CoinMine Telegram Mini App — Prototype

This is a front-end prototype for a Telegram Mini App.

Included:
- Mining screen with virtual coin balance
- Wallet
- Transfer UI
- Referral UI
- Profile
- Transaction history
- Settings
- Telegram WebApp SDK integration
- Local demo storage

Important:
This version uses localStorage and is NOT a real cryptocurrency/mining system.
For production, add a secure backend, database, Telegram initData validation, server-side mining calculations,
transaction authorization, rate limits, and proper authentication.

## Run locally
Open index.html in a browser. For Telegram Mini Apps, deploy the folder to an HTTPS host.

## Telegram connection
1. Create a bot with @BotFather.
2. Host this folder on an HTTPS URL.
3. Configure the bot's Web App / menu button to open that URL.
4. Open the bot in Telegram and launch the Mini App.

Do not publish a Bot Token inside this HTML file.
